# tweetsAnalytics

```sh
git clone
install nodejs
npm install
npm start
http://localhost:3000/
```